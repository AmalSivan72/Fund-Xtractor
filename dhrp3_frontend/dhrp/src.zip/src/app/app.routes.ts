import { Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { TocBrowser } from './toc-browser/toc-browser';
import { RiskBrowser } from './risk-browser/risk-browser';
import { CompanyBrowser } from './company-browser/company-browser';

export const routes: Routes = [
    { path: '', component: Dashboard },  
    { path: 'dashboard', component: Dashboard },
    { path: 'toc-browser', component: TocBrowser },
    { path: 'risk-browser', component: RiskBrowser },
    { path: 'company-browser', component: CompanyBrowser }
];
