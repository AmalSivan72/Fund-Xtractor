import { Component,OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-toc-browser',
  imports: [CommonModule],
  templateUrl: './toc-browser.html',
  styleUrl: './toc-browser.css'
})
export class TocBrowser implements OnInit{
  entries: any[] = [];
  selectedTOC: any = null;
  selectedDoc: string = '';

  ngOnInit(): void {
    fetch('http://localhost:5000/get_all_dhrps')
      .then(res => res.json())
      .then(data => this.entries = data)
      .catch(() => alert('Failed to load DHRP entries.'));
  }

  loadTOC(doc: string) {
    this.selectedDoc = doc;
    fetch(`http://localhost:5000/get_toc/${doc}`)
      .then(res => res.json())
      .then(data => {
        if (data.toc) {
          this.selectedTOC = data.toc;
        } else {
          this.selectedTOC = null;
          alert('TOC not found.');
        }
      })
      .catch(() => alert('Error loading TOC.'));
  }
}
