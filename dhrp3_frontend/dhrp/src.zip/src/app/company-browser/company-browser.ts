import { Component } from '@angular/core';

@Component({
  selector: 'app-company-browser',
  imports: [],
  templateUrl: './company-browser.html',
  styleUrl: './company-browser.css'
})
export class CompanyBrowser {

}
