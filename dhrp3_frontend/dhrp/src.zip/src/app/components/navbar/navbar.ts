import { Component,Output,EventEmitter} from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-navbar',
  imports: [FormsModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {
  @Output() toggleSidebar = new EventEmitter<void>();
  pdfFile: File | null = null;

  openModal() {
    const modal = new (window as any).bootstrap.Modal(document.getElementById('uploadModal'));
    modal.show();
  }

  onFileChange(event: any) {
    this.pdfFile = event.target.files[0];
  }

  onSubmit(form: any) {
    const formData = new FormData();
    formData.append('company', form.value.company);
    formData.append('bse_code', form.value.bse_code);
    formData.append('upload_date', form.value.upload_date);
    formData.append('sector', form.value.sector);
    formData.append('promoter', form.value.promoter);
    formData.append('pdf', this.pdfFile as Blob);

    fetch('http://localhost:5000/', {
      method: 'POST',
      body: formData
    }).then(response => {
      if (response.redirected) {
        window.location.href = response.url;
      } else {
        alert('Upload failed.');
      }
    }).catch(() => {
      alert('Upload error.');
    });
  }
  triggerSidebar() {
    this.toggleSidebar.emit();  // ✅ Trigger sidebar toggle
  }

}
