import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  entries: any[] = [];

  ngOnInit(): void {
    fetch('http://localhost:5000/get_all_dhrps')

      .then(res => res.json())
      .then(data => this.entries = data)
      .catch(() => alert('Failed to load DHRP entries.'));
  }

  viewTOC(doc: string) {
    window.open(`http://localhost:5000/toc/${doc}`, '_blank');
  }

  viewRisk(doc: string) {
    window.open(`http://localhost:5000/risk/${doc}`, '_blank');
  }

  deleteDoc(doc: string) {
    fetch(`http://localhost:5000/delete/${doc}`, {
      method: 'POST'
    }).then(() => {
      this.entries = this.entries.filter(e => e.pdf_filename !== doc);
    }).catch(() => alert('Delete failed.'));
  }
}
