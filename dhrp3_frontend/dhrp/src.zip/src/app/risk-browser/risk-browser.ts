import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-risk-browser',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './risk-browser.html',
  styleUrl: './risk-browser.css'
})
export class RiskBrowser implements OnInit {
  entries: any[] = [];
  filteredEntries: any[] = [];
  selectedCompany: string = '';
  selectedDoc: string = '';
  searchQuery: string = '';

  ngOnInit(): void {
    fetch('http://127.0.0.1:5000/get_all_dhrps')
      .then(res => res.json())
      .then(data => {
        this.entries = data;
        this.filteredEntries = data;
      })
      .catch(() => alert('Failed to load entries.'));
  }

  search(query: string) {
    this.searchQuery = query.toLowerCase();
    this.filteredEntries = this.entries.filter(e =>
      e.company.toLowerCase().includes(this.searchQuery)
    );
  }

  select(entry: any) {
    this.selectedCompany = entry.company;
    this.selectedDoc = entry.pdf_filename;
  }
}
